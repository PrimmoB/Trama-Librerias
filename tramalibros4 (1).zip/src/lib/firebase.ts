import { initializeApp, getApps, getApp, FirebaseApp } from "firebase/app";
import {
  getFirestore,
  initializeFirestore,
  collection,
  onSnapshot,
  doc,
  setDoc,
  deleteDoc,
  writeBatch,
  getDocs,
  Firestore,
  Unsubscribe,
} from "firebase/firestore";
import defaultFirebaseConfig from "../../firebase-applet-config.json";

// Map de colecciones a claves de localStorage utilizadas por la app
export const storageKeyMap: Record<string, string> = {
  books: "trama_books",
  ventas: "trama_ventas",
  proveedores: "trama_proveedores",
  librerias: "trama_librerias_data",
  accesos: "trama_accesos",
  movimientos: "trama_movimientos",
  gastos: "trama_gastos",
  otrosIngresos: "trama_otros_ingresos",
  auditLogs: "trama_audit_logs",
  infoEmpresa: "trama_info_data",
  cierresCaja: "trama_cierres_caja",
  liquidaciones: "trama_liquidaciones",
  aperturaActiva: "trama_apertura_activa",
};

export interface FirebaseSyncCollectionInfo {
  status: "synced" | "syncing" | "error" | "offline";
  docsCount: number;
  lastUpdated?: string;
  errorMessage?: string;
}

export interface FirebaseSyncLogEntry {
  id: string;
  timestamp: string;
  type: "success" | "syncing" | "error" | "info";
  collection: string;
  message: string;
}

export interface FirebaseSyncStatus {
  isAvailable: boolean;
  status: "connected" | "syncing" | "offline" | "error";
  lastSyncTime: string | null;
  lastOperation: string;
  writeErrors: number;
  readErrors: number;
  lastErrorMessage: string | null;
  collections: Record<string, FirebaseSyncCollectionInfo>;
  logs: FirebaseSyncLogEntry[];
}

// Configuración combinando variables de entorno Vercel/Vite y el archivo JSON oficial del Applet
const firebaseConfig = {
  projectId: import.meta.env.VITE_FIREBASE_PROJECT_ID || defaultFirebaseConfig.projectId || "single-crow-5f6jr",
  appId: import.meta.env.VITE_FIREBASE_APP_ID || defaultFirebaseConfig.appId || "1:683975518409:web:30270491b492359ea8c518",
  apiKey: import.meta.env.VITE_FIREBASE_API_KEY || defaultFirebaseConfig.apiKey || "AIzaSyD-GMtP158C06gow_jRcVvNDVPltWtPucM",
  authDomain: import.meta.env.VITE_FIREBASE_AUTH_DOMAIN || defaultFirebaseConfig.authDomain || "single-crow-5f6jr.firebaseapp.com",
  storageBucket: import.meta.env.VITE_FIREBASE_STORAGE_BUCKET || defaultFirebaseConfig.storageBucket || "single-crow-5f6jr.firebasestorage.app",
  messagingSenderId: import.meta.env.VITE_FIREBASE_MESSAGING_SENDER_ID || defaultFirebaseConfig.messagingSenderId || "683975518409",
};

let app: FirebaseApp | null = null;
export let db: Firestore | null = null;
export let isFirebaseAvailable = false;

// Estado Global de Sincronización en Tiempo Real
const syncStatusState: FirebaseSyncStatus = {
  isAvailable: false,
  status: "offline",
  lastSyncTime: null,
  lastOperation: "Inicializando conexión con Firebase...",
  writeErrors: 0,
  readErrors: 0,
  lastErrorMessage: null,
  collections: {
    books: { status: "offline", docsCount: 0 },
    ventas: { status: "offline", docsCount: 0 },
    proveedores: { status: "offline", docsCount: 0 },
    librerias: { status: "offline", docsCount: 0 },
    accesos: { status: "offline", docsCount: 0 },
    movimientos: { status: "offline", docsCount: 0 },
    gastos: { status: "offline", docsCount: 0 },
    otrosIngresos: { status: "offline", docsCount: 0 },
    auditLogs: { status: "offline", docsCount: 0 },
    infoEmpresa: { status: "offline", docsCount: 0 },
    cierresCaja: { status: "offline", docsCount: 0 },
    liquidaciones: { status: "offline", docsCount: 0 },
    aperturaActiva: { status: "offline", docsCount: 0 },
  },
  logs: [],
};

const syncStatusListeners = new Set<(status: FirebaseSyncStatus) => void>();

export function subscribeFirebaseSyncStatus(callback: (status: FirebaseSyncStatus) => void): () => void {
  syncStatusListeners.add(callback);
  callback(getFirebaseSyncStatus());
  return () => {
    syncStatusListeners.delete(callback);
  };
}

export function getFirebaseSyncStatus(): FirebaseSyncStatus {
  return {
    ...syncStatusState,
    collections: { ...syncStatusState.collections },
    logs: [...syncStatusState.logs],
  };
}

function updateSyncStatus(updater: (prev: FirebaseSyncStatus) => void) {
  updater(syncStatusState);
  const snapshot = getFirebaseSyncStatus();
  syncStatusListeners.forEach(cb => cb(snapshot));
}

function addSyncLog(type: "success" | "syncing" | "error" | "info", collectionName: string, message: string) {
  const timeZoneStr = new Date().toLocaleTimeString("es-CL", { timeZone: "America/Santiago" });
  const entry: FirebaseSyncLogEntry = {
    id: `${Date.now()}-${Math.random()}`,
    timestamp: timeZoneStr,
    type,
    collection: collectionName,
    message,
  };
  syncStatusState.logs = [entry, ...syncStatusState.logs].slice(0, 40);
}

// Control interno de sincronización y prevención de loops
const isRemoteUpdating: Record<string, boolean> = {};
const lastDataSignatures: Record<string, string> = {};
const knownFirestoreDocIds: Record<string, Set<string>> = {};
const initialSyncDone: Record<string, boolean> = {};

/**
 * Sanitiza recursivamente objetos eliminando propiedades 'undefined' o funciones
 */
export function sanitizeForFirestore<T>(data: T): T {
  if (data === undefined || data === null) return data;
  return JSON.parse(JSON.stringify(data));
}

export function calculateFingerprint(data: any): string {
  try {
    if (data === null || data === undefined) return "";
    return JSON.stringify(data);
  } catch {
    return "";
  }
}

try {
  if (typeof window !== "undefined") {
    app = getApps().length > 0 ? getApp() : initializeApp(firebaseConfig);
    const dbId =
      import.meta.env.VITE_FIREBASE_DATABASE_ID ||
      defaultFirebaseConfig.firestoreDatabaseId ||
      (defaultFirebaseConfig as any).databaseId;

    if (dbId) {
      try {
        db = getFirestore(app, dbId);
      } catch (e) {
        db = initializeFirestore(app, { ignoreUndefinedProperties: true }, dbId);
      }
    } else {
      try {
        db = getFirestore(app);
      } catch (e) {
        db = initializeFirestore(app, { ignoreUndefinedProperties: true });
      }
    }

    if (db) {
      isFirebaseAvailable = true;
      syncStatusState.isAvailable = true;
      syncStatusState.status = "connected";
      syncStatusState.lastSyncTime = new Date().toLocaleTimeString("es-CL", { timeZone: "America/Santiago" });
      syncStatusState.lastOperation = `Conectado a Firestore (${dbId || "default"})`;
      addSyncLog("info", "sistema", "Conexión a Firebase Cloud Firestore establecida con éxito.");
    }
  }
} catch (err: any) {
  console.warn("[Firebase] Error en inicialización de Firestore:", err);
  db = null;
  isFirebaseAvailable = false;
  syncStatusState.isAvailable = false;
  syncStatusState.status = "error";
  syncStatusState.lastErrorMessage = err?.message || String(err);
  addSyncLog("error", "sistema", `Error al inicializar Firebase: ${syncStatusState.lastErrorMessage}`);
}

/**
 * Realiza un test de diagnóstico enviando un ping a Firestore para verificar lectura y escritura en tiempo real
 */
export async function testFirebaseConnection(): Promise<{ success: boolean; latencyMs: number; message: string }> {
  const startTime = Date.now();
  if (!db || !isFirebaseAvailable) {
    updateSyncStatus(s => {
      s.status = "offline";
      s.lastErrorMessage = "Firebase no disponible o sin conexión";
    });
    return { success: false, latencyMs: 0, message: "Firebase no está inicializado o no hay conexión." };
  }

  try {
    updateSyncStatus(s => {
      s.status = "syncing";
      s.lastOperation = "Probando conexión (Ping Firestore)...";
    });

    const testDocRef = doc(db, "_sync_test", "ping");
    const timestamp = new Date().toISOString();
    await setDoc(testDocRef, { ping: true, timestamp, app: "Trama Librerías", updatedAt: Date.now() }, { merge: true });

    const latencyMs = Date.now() - startTime;
    const timeStr = new Date().toLocaleTimeString("es-CL", { timeZone: "America/Santiago" });

    updateSyncStatus(s => {
      s.status = "connected";
      s.lastSyncTime = timeStr;
      s.lastOperation = `Ping de lectura/escritura exitoso (${latencyMs} ms)`;
      s.lastErrorMessage = null;
    });

    addSyncLog("success", "ping", `Prueba de escritura/lectura en tiempo real exitosa (${latencyMs} ms).`);

    return {
      success: true,
      latencyMs,
      message: `Conexión activa con Firebase Cloud Firestore. Latencia de respuesta: ${latencyMs} ms.`
    };
  } catch (err: any) {
    const latencyMs = Date.now() - startTime;
    const errMsg = err?.message || String(err);

    updateSyncStatus(s => {
      s.status = "error";
      s.writeErrors += 1;
      s.lastErrorMessage = errMsg;
    });

    addSyncLog("error", "ping", `Error en prueba de ping: ${errMsg}`);

    return {
      success: false,
      latencyMs,
      message: `Error de respuesta o escritura en Firestore: ${errMsg}`
    };
  }
}

/**
 * Suscribirse a una colección de Firestore con sincronización bidireccional inmediata
 */
export function syncCollection<T extends { id: string | number; updatedAt?: number }>(
  collectionName: string,
  onUpdate: (data: T[]) => void,
  initialData: T[] = []
): Unsubscribe {
  const localKey = storageKeyMap[collectionName] || collectionName;

  if (!db || !isFirebaseAvailable) {
    updateSyncStatus(s => {
      if (s.collections[collectionName]) {
        s.collections[collectionName].status = "offline";
      }
    });
    return () => {};
  }

  try {
    const colRef = collection(db, collectionName);

    const unsubscribe = onSnapshot(
      colRef,
      async (snapshot) => {
        try {
          isRemoteUpdating[collectionName] = true;
          const timeStr = new Date().toLocaleTimeString("es-CL", { timeZone: "America/Santiago" });

          const remoteItems: T[] = [];
          const currentDocIds = new Set<string>();

          snapshot.forEach((docSnap) => {
            const item = docSnap.data() as T;
            if (item && item.id != null) {
              remoteItems.push(item);
              currentDocIds.add(String(item.id));
            }
          });

          knownFirestoreDocIds[collectionName] = currentDocIds;

          // Leer estado local actual
          const localRaw = typeof window !== "undefined" ? localStorage.getItem(localKey) : null;
          let localItems: T[] = [];
          if (localRaw) {
            try {
              const parsed = JSON.parse(localRaw);
              if (Array.isArray(parsed)) localItems = parsed;
            } catch {}
          }

          let finalItems: T[] = [];

          if (snapshot.empty) {
            // Firestore está vacío: si hay datos locales o iniciales, los subimos a Firestore
            if (localItems.length > 0) {
              finalItems = localItems;
              saveEntireCollection(collectionName, finalItems);
            } else if (initialData.length > 0) {
              finalItems = initialData;
              saveEntireCollection(collectionName, finalItems);
            } else {
              finalItems = [];
            }
          } else {
            // Firestore tiene datos
            if (!initialSyncDone[collectionName]) {
              // Primera sincronización al arrancar: combinar ítems locales creados offline con los de Firestore
              const remoteMap = new Map<string, T>(remoteItems.map(it => [String(it.id), it]));
              const merged: T[] = [...remoteItems];

              // Si había items locales que no están en Firestore, preservarlos
              localItems.forEach(loc => {
                if (loc && loc.id != null && !remoteMap.has(String(loc.id))) {
                  merged.push(loc);
                }
              });

              finalItems = merged;
              initialSyncDone[collectionName] = true;

              if (finalItems.length > remoteItems.length) {
                saveEntireCollection(collectionName, finalItems);
              }
            } else {
              // Sincronizaciones subsiguientes: Firestore es la fuente autoritativa
              finalItems = remoteItems;
            }
          }

          // Guardar en localStorage
          if (typeof window !== "undefined") {
            try {
              localStorage.setItem(localKey, JSON.stringify(finalItems));
            } catch {}
          }

          // Actualizar firma para evitar bucles de actualización
          lastDataSignatures[collectionName] = calculateFingerprint(finalItems);

          // Notificar a React
          onUpdate(finalItems);

          updateSyncStatus(s => {
            s.status = "connected";
            s.lastSyncTime = timeStr;
            s.lastOperation = `Sincronización '${collectionName}' (${finalItems.length} registros)`;
            s.collections[collectionName] = {
              status: "synced",
              docsCount: finalItems.length,
              lastUpdated: timeStr,
            };
          });

          setTimeout(() => {
            isRemoteUpdating[collectionName] = false;
          }, 80);
        } catch (innerErr: any) {
          isRemoteUpdating[collectionName] = false;
          console.warn(`[Firebase] Error procesando snapshot '${collectionName}':`, innerErr);
          updateSyncStatus(s => {
            s.status = "error";
            s.readErrors += 1;
            s.lastErrorMessage = innerErr?.message || String(innerErr);
            s.collections[collectionName] = {
              status: "error",
              docsCount: s.collections[collectionName]?.docsCount || 0,
              errorMessage: innerErr?.message || String(innerErr)
            };
          });
        }
      },
      (error) => {
        isRemoteUpdating[collectionName] = false;
        console.warn(`[Firebase] Escuchador de '${collectionName}' offline o error:`, error.message);
        updateSyncStatus(s => {
          s.status = "error";
          s.readErrors += 1;
          s.lastErrorMessage = error.message;
          s.collections[collectionName] = {
            status: "error",
            docsCount: s.collections[collectionName]?.docsCount || 0,
            errorMessage: error.message
          };
        });
      }
    );

    return unsubscribe;
  } catch (err: any) {
    console.warn(`[Firebase] Error conectando a '${collectionName}':`, err);
    return () => {};
  }
}

/**
 * Guarda o actualiza un documento individual en Firestore y localStorage inmediatamente
 */
export async function saveDocument<T extends { id: string | number; updatedAt?: number }>(
  collectionName: string,
  item: T
) {
  if (!item || item.id == null) return;
  const docId = String(item.id);
  const timeNow = Date.now();
  (item as any).updatedAt = timeNow;

  // Actualizar inmediatamente en localStorage
  const localKey = storageKeyMap[collectionName] || collectionName;
  if (typeof window !== "undefined") {
    try {
      const raw = localStorage.getItem(localKey);
      if (raw) {
        const arr = JSON.parse(raw);
        if (Array.isArray(arr)) {
          const idx = arr.findIndex((x: any) => String(x.id) === docId);
          if (idx >= 0) {
            arr[idx] = item;
          } else {
            arr.unshift(item);
          }
          localStorage.setItem(localKey, JSON.stringify(arr));
        }
      }
    } catch {}
  }

  if (!db || !isFirebaseAvailable) return;

  try {
    const sanitized = sanitizeForFirestore(item);
    const docRef = doc(db, collectionName, docId);
    await setDoc(docRef, sanitized, { merge: true });

    if (!knownFirestoreDocIds[collectionName]) {
      knownFirestoreDocIds[collectionName] = new Set<string>();
    }
    knownFirestoreDocIds[collectionName].add(docId);

    const timeStr = new Date().toLocaleTimeString("es-CL", { timeZone: "America/Santiago" });
    updateSyncStatus(s => {
      s.status = "connected";
      s.lastSyncTime = timeStr;
      s.lastOperation = `Documento #${docId} guardado en '${collectionName}'`;
      if (s.collections[collectionName]) {
        s.collections[collectionName].status = "synced";
        s.collections[collectionName].lastUpdated = timeStr;
      }
    });
    addSyncLog("success", collectionName, `Documento #${docId} persistido en Firestore.`);
  } catch (err: any) {
    console.warn(`[Firebase] Error al guardar documento #${docId} en '${collectionName}':`, err);
    const errMsg = err?.message || String(err);
    updateSyncStatus(s => {
      s.status = "error";
      s.writeErrors += 1;
      s.lastErrorMessage = errMsg;
    });
    addSyncLog("error", collectionName, `Error al guardar documento #${docId}: ${errMsg}`);
  }
}

/**
 * Elimina un documento individual en Firestore y localStorage por ID
 */
export async function deleteDocument(
  collectionName: string,
  docId: string | number
) {
  if (docId == null) return;
  const idStr = String(docId);

  // Actualizar inmediatamente en localStorage
  const localKey = storageKeyMap[collectionName] || collectionName;
  if (typeof window !== "undefined") {
    try {
      const raw = localStorage.getItem(localKey);
      if (raw) {
        const arr = JSON.parse(raw);
        if (Array.isArray(arr)) {
          const filtered = arr.filter((x: any) => String(x.id) !== idStr);
          localStorage.setItem(localKey, JSON.stringify(filtered));
        }
      }
    } catch {}
  }

  if (!db || !isFirebaseAvailable) return;

  try {
    const docRef = doc(db, collectionName, idStr);
    await deleteDoc(docRef);

    if (knownFirestoreDocIds[collectionName]) {
      knownFirestoreDocIds[collectionName].delete(idStr);
    }

    const timeStr = new Date().toLocaleTimeString("es-CL", { timeZone: "America/Santiago" });
    updateSyncStatus(s => {
      s.status = "connected";
      s.lastSyncTime = timeStr;
      s.lastOperation = `Documento #${idStr} eliminado de '${collectionName}'`;
      if (s.collections[collectionName]) {
        s.collections[collectionName].status = "synced";
        s.collections[collectionName].lastUpdated = timeStr;
      }
    });
    addSyncLog("success", collectionName, `Documento #${idStr} eliminado de Firestore.`);
  } catch (err: any) {
    console.warn(`[Firebase] Error al eliminar doc #${idStr} en '${collectionName}':`, err);
  }
}

/**
 * Sincroniza la colección completa en Firestore y localStorage
 */
export async function saveEntireCollection<T extends { id: string | number; updatedAt?: number }>(
  collectionName: string,
  data: T[]
) {
  if (!Array.isArray(data)) return;

  const localKey = storageKeyMap[collectionName] || collectionName;

  // Persistencia local instantánea
  if (typeof window !== "undefined") {
    try {
      localStorage.setItem(localKey, JSON.stringify(data));
    } catch {}
  }

  // Evitar re-escribir si la actualización vino de un snapshot remoto
  if (isRemoteUpdating[collectionName]) {
    return;
  }

  const fingerprint = calculateFingerprint(data);
  if (lastDataSignatures[collectionName] === fingerprint) {
    return;
  }

  lastDataSignatures[collectionName] = fingerprint;

  if (!db || !isFirebaseAvailable) {
    return;
  }

  try {
    const currentDocIds = new Set<string>();
    const sanitizedData = data.map(item => {
      const sanitized = sanitizeForFirestore(item);
      if (!(sanitized as any).updatedAt) {
        (sanitized as any).updatedAt = Date.now();
      }
      if (sanitized && sanitized.id != null) {
        currentDocIds.add(String(sanitized.id));
      }
      return sanitized;
    });

    const previousDocIds = knownFirestoreDocIds[collectionName] || new Set<string>();

    // Operaciones en batch (crear/actualizar y eliminar)
    const ops: Array<{ type: "set"; ref: any; docData: any } | { type: "delete"; ref: any }> = [];

    sanitizedData.forEach((item) => {
      if (item && item.id != null) {
        const docRef = doc(db!, collectionName, String(item.id));
        ops.push({ type: "set", ref: docRef, docData: item });
      }
    });

    // Detectar eliminaciones sólo si ya teníamos documentos conocidos
    if (previousDocIds.size > 0) {
      previousDocIds.forEach((oldId) => {
        if (!currentDocIds.has(oldId)) {
          const docRef = doc(db!, collectionName, oldId);
          ops.push({ type: "delete", ref: docRef });
        }
      });
    }

    if (ops.length > 0) {
      for (let i = 0; i < ops.length; i += 400) {
        const batch = writeBatch(db!);
        const chunk = ops.slice(i, i + 400);
        chunk.forEach((op) => {
          if (op.type === "set") {
            batch.set(op.ref, op.docData, { merge: true });
          } else {
            batch.delete(op.ref);
          }
        });
        await batch.commit();
      }
    }

    knownFirestoreDocIds[collectionName] = currentDocIds;

    const timeStr = new Date().toLocaleTimeString("es-CL", { timeZone: "America/Santiago" });
    updateSyncStatus(s => {
      s.status = "connected";
      s.lastSyncTime = timeStr;
      s.lastOperation = `Guardado exitoso '${collectionName}' (${sanitizedData.length} registros)`;
      s.collections[collectionName] = {
        status: "synced",
        docsCount: sanitizedData.length,
        lastUpdated: timeStr,
      };
    });
  } catch (err: any) {
    console.warn(`[Firebase] Error al sincronizar '${collectionName}':`, err);
    const errMsg = err?.message || String(err);
    updateSyncStatus(s => {
      s.status = "error";
      s.writeErrors += 1;
      s.lastErrorMessage = errMsg;
      s.collections[collectionName] = {
        status: "error",
        docsCount: data.length,
        errorMessage: errMsg
      };
    });
  }
}

/**
 * Guarda o actualiza el documento de información de la empresa
 */
export async function saveInfoEmpresa(info: any) {
  if (!info) return;

  if (typeof window !== "undefined") {
    try {
      localStorage.setItem("trama_info_data", JSON.stringify(info));
    } catch {}
  }

  if (isRemoteUpdating["infoEmpresa"]) return;

  const fingerprint = calculateFingerprint(info);
  if (lastDataSignatures["infoEmpresa"] === fingerprint) return;
  lastDataSignatures["infoEmpresa"] = fingerprint;

  if (!db || !isFirebaseAvailable) return;

  try {
    const sanitized = sanitizeForFirestore(info);
    if (!sanitized.updatedAt) sanitized.updatedAt = Date.now();
    const docRef = doc(db, "infoEmpresa", "general");
    await setDoc(docRef, sanitized, { merge: true });

    const timeStr = new Date().toLocaleTimeString("es-CL", { timeZone: "America/Santiago" });
    updateSyncStatus(s => {
      s.status = "connected";
      s.lastSyncTime = timeStr;
      s.lastOperation = "Información corporativa guardada";
      if (s.collections.infoEmpresa) {
        s.collections.infoEmpresa.status = "synced";
        s.collections.infoEmpresa.docsCount = 1;
        s.collections.infoEmpresa.lastUpdated = timeStr;
      }
    });
  } catch (err: any) {
    console.warn("[Firebase] Error guardando infoEmpresa:", err);
  }
}

/**
 * Suscribe la información general de la empresa
 */
export function syncInfoEmpresa(
  onUpdate: (info: any) => void,
  initialInfo: any
): Unsubscribe {
  if (!db || !isFirebaseAvailable) {
    return () => {};
  }
  try {
    const docRef = doc(db, "infoEmpresa", "general");
    return onSnapshot(
      docRef,
      async (docSnap) => {
        isRemoteUpdating["infoEmpresa"] = true;
        const timeStr = new Date().toLocaleTimeString("es-CL", { timeZone: "America/Santiago" });

        let finalInfo = initialInfo;
        if (docSnap.exists()) {
          finalInfo = { ...initialInfo, ...docSnap.data() };
        } else {
          // Si no existe, guardar inicial
          await saveInfoEmpresa(initialInfo);
        }

        if (typeof window !== "undefined") {
          try {
            localStorage.setItem("trama_info_data", JSON.stringify(finalInfo));
          } catch {}
        }

        lastDataSignatures["infoEmpresa"] = calculateFingerprint(finalInfo);
        onUpdate(finalInfo);

        updateSyncStatus(s => {
          s.status = "connected";
          s.lastSyncTime = timeStr;
          s.lastOperation = "Información corporativa sincronizada";
          if (s.collections.infoEmpresa) {
            s.collections.infoEmpresa.status = "synced";
            s.collections.infoEmpresa.docsCount = 1;
            s.collections.infoEmpresa.lastUpdated = timeStr;
          }
        });

        setTimeout(() => {
          isRemoteUpdating["infoEmpresa"] = false;
        }, 80);
      },
      (error) => {
        isRemoteUpdating["infoEmpresa"] = false;
        console.warn("[Firebase] Escuchador infoEmpresa offline:", error.message);
      }
    );
  } catch (err: any) {
    return () => {};
  }
}

/**
 * Guarda o actualiza el documento de apertura de caja activa
 */
export async function saveAperturaActiva(apertura: any) {
  if (typeof window !== "undefined") {
    try {
      localStorage.setItem("trama_apertura_activa", JSON.stringify(apertura));
    } catch {}
  }

  if (isRemoteUpdating["aperturaActiva"]) return;

  const fingerprint = calculateFingerprint(apertura);
  if (lastDataSignatures["aperturaActiva"] === fingerprint) return;
  lastDataSignatures["aperturaActiva"] = fingerprint;

  if (!db || !isFirebaseAvailable) return;

  try {
    const docRef = doc(db, "aperturaActiva", "actual");
    if (apertura === null) {
      await deleteDoc(docRef);
    } else {
      const sanitized = sanitizeForFirestore(apertura);
      if (!sanitized.updatedAt) sanitized.updatedAt = Date.now();
      await setDoc(docRef, sanitized, { merge: true });
    }
  } catch (err: any) {
    console.warn("[Firebase] Error guardando aperturaActiva:", err);
  }
}

/**
 * Suscribe la apertura de caja activa
 */
export function syncAperturaActiva(
  onUpdate: (apertura: any) => void,
  initialApertura: any = null
): Unsubscribe {
  if (!db || !isFirebaseAvailable) {
    return () => {};
  }
  try {
    const docRef = doc(db, "aperturaActiva", "actual");
    return onSnapshot(
      docRef,
      (docSnap) => {
        isRemoteUpdating["aperturaActiva"] = true;
        let finalApertura = initialApertura;
        if (docSnap.exists()) {
          finalApertura = docSnap.data();
        } else {
          finalApertura = null;
        }

        if (typeof window !== "undefined") {
          try {
            localStorage.setItem("trama_apertura_activa", JSON.stringify(finalApertura));
          } catch {}
        }

        lastDataSignatures["aperturaActiva"] = calculateFingerprint(finalApertura);
        onUpdate(finalApertura);

        setTimeout(() => {
          isRemoteUpdating["aperturaActiva"] = false;
        }, 80);
      },
      (error) => {
        isRemoteUpdating["aperturaActiva"] = false;
        console.warn("[Firebase] Escuchador aperturaActiva offline:", error.message);
      }
    );
  } catch (err: any) {
    return () => {};
  }
}
